exports.response = function (req, res) {
  return {
    "code": "0",
    "msg": "OK",
    "resultData": {
      "fileName": "f8ab2a58-c2a0-4495-95cd-48ebb846d07a.csv",
      "totalCustNum": 562
    }
  };
}
