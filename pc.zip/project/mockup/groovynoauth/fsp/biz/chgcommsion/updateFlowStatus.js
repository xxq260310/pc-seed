/**
 * @Author: sunweibin
 * @Date: 2017-11-03 19:18:50
 * @Last Modified by: sunweibin
 * @Last Modified time: 2017-11-03 19:19:39
 * @description 结转流程状态
 */

exports.response = function (req, res) {
  return {
    code: '0',
    msg: '',
    resultData: true,
  };
};
