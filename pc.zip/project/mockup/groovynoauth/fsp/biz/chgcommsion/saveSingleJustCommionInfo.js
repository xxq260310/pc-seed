/**
 * @Author: sunweibin
 * @Date: 2017-10-26 16:01:43
 * @Last Modified by: sunweibin
 * @Last Modified time: 2017-10-26 16:02:55
 * @description 单佣金调整提交
 */
exports.response = function (req, res) {
  return {
    code: '0',
    msg: 'OK',
    resultData: {
      id: '1-xxxxxj',
    },
  };
};
