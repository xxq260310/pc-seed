/**
 * @description 提交批量佣金调整申请
 * @author sunweibin
 */

exports.response = function (req, res) {
  return {
    code: '0',
    msg: 'OK',
    resultData: {
      batchnum: '1-433SIU8',
    },
  };
};
