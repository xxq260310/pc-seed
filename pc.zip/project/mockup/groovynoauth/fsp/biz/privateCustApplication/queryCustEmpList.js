exports.response = function (req, res) {
  return {
    "code": "0",
    "msg": "OK",
    "resultData": [
      {
        "ptyMngId": "002332",
        "ptyMngName": "王华",
        "job": "HTSC002332",
        "businessDepartment": "南京长江路证券营业部",
        "isMain": "Y"
      }, {
        "ptyMngId": "001477",
        "ptyMngName": "sxx",
        "job": "南京长江路证券营业部",
        "businessDepartment": "南京长江路证券营业部",
        "isMain": "N"
      }, {
        "ptyMngId": "0023354",
        "ptyMngName": "王华",
        "job": "HTSC002332",
        "businessDepartment": "南京长江路证券营业部",
        "isMain": "Y"
      }, {
        "ptyMngId": "0014755",
        "ptyMngName": "wjf",
        "job": "南京长江路证券营业部",
        "businessDepartment": "南京长江路证券营业部",
        "isMain": "N"
      }
    ],
  };
}

