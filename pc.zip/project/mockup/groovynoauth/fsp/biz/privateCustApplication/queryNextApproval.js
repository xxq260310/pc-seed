exports.response = function (req, res) {
  return {
    "code": "0",
    "msg": "OK",
    "resultData": {
      "approverList": [
        {
          "ptyMngId": "123",
          "ptyMngName": "AAAA",
          "job": "HTSC002332",
          "businessDepartment": "南京长江路证券营业部",
        }, {
          "ptyMngId": "123456",
          "ptyMngName": "BBBB",
          "job": "南京长江路证券营业部",
          "businessDepartment": "南京长江路证券营业部",
        }, {
          "ptyMngId": "dfdf25",
          "ptyMngName": "CCCC",
          "job": "南京长江路证券营业部",
          "businessDepartment": "南京长江路证券营业部",
        }, {
          "ptyMngId": "5154sdfsdf",
          "ptyMngName": "sdafsdf",
          "job": "南京长江路证券营业部",
          "businessDepartment": "南京长江路证券营业部",
        }, {
          "ptyMngId": "sdfsfs",
          "ptyMngName": "dfgdgfgh",
          "job": "南京长江路证券营业部",
          "businessDepartment": "南京长江路证券营业部",
        },
      ],
    },
  };
}
