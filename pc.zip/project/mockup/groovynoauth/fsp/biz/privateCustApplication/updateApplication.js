exports.response = function (req, res) {
  return {
    "code": "0",
    "msg": "OK",
    "resultData": {
      "applyId":"001",
      "wobNum":"001",
      "businessObj":"001",
      "stepName":"001",
      "flowClass":"001",
      "subject":"001",
    },
  };
}
