exports.response = function (req, res) {
  return {
    "code": "0",
    "msg": "OK",
    "resultData": [
      {
        "val": "紫金快车道协议",
        "name": "507070",
        "faName": "502010",
        "type": "FINS_INVST_CATEGORY",
        "rowId": "1-3PX34LH"
      }
    ]
  }
}
