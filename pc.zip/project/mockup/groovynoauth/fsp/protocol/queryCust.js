exports.response = function (req, res) {
  return {
    "code": "0",
    "msg": "OK",
    "resultData": {
      "custId" : "1-2SJYOIW",
      "custName" : "1-2SJYOIW",
      "econNum" : "02041745",
      "subCustType" : "个人客户",
    }
  }
}
