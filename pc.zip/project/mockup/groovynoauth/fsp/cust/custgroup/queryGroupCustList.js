exports.response = function (req, res) {
  return {
    "code": "0",
    "msg": "OK",
    "resultData": {
      "pageSize": null,
      "curPageNum": null,
      "totalPageNum": 1,
      "totalRecordNum": 1,
      "groupName": null,
      "groupDesc": null,
      "groupCustDTOList": [
        {
          "custName": "1-5TTJ-3900",
          "custId": "118000119822",
          "levelName": "钻石",
          "riskLevelName": "稳定"
        }
      ]
    }
  }
}