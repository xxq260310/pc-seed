exports.response = function (req, res) {
    return {
        "code": "0",
        "msg": "OK",
        "resultData": {
            pageSize: null,
            curPageNum: null,
            totalPageNum: 4,
            totalRecordNum: 40,
            custGroupDTOList: [
                {
                    "groupId": "001",
                    "groupName": "testfdfdsafdsafdsfdsafdsafdsfdsafdafdsa",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "002",
                    "groupName": "test2dsdsdsdsdsdsdsdsdsdsdsdsdsdsdsdsdsdsds",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是testdsdssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssdsdsds"
                },
                {
                    "groupId": "003",
                    "groupName": "test3",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "004",
                    "groupName": "test4",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "005",
                    "groupName": "test5",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "006",
                    "groupName": "test6",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "007",
                    "groupName": "test7",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "008",
                    "groupName": "test8",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "009",
                    "groupName": "test9",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "0010",
                    "groupName": "test10",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "001",
                    "groupName": "test",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "002",
                    "groupName": "test2",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "003",
                    "groupName": "test3",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "004",
                    "groupName": "test4",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "005",
                    "groupName": "test5",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "006",
                    "groupName": "test6",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "007",
                    "groupName": "test7",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "008",
                    "groupName": "test8",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "009",
                    "groupName": "test9",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "0010",
                    "groupName": "test10",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "001",
                    "groupName": "test",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "002",
                    "groupName": "test2",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "003",
                    "groupName": "test3",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "004",
                    "groupName": "test4",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "005",
                    "groupName": "test5",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "006",
                    "groupName": "test6",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "007",
                    "groupName": "test7",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "008",
                    "groupName": "test8",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "009",
                    "groupName": "test9",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "0010",
                    "groupName": "test10",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "001",
                    "groupName": "test",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "002",
                    "groupName": "test2",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "003",
                    "groupName": "test3",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "004",
                    "groupName": "test4",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "005",
                    "groupName": "test5",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "006",
                    "groupName": "test6",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "007",
                    "groupName": "test7",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "008",
                    "groupName": "test8",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "009",
                    "groupName": "test9",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
                {
                    "groupId": "0010",
                    "groupName": "test10",
                    "relatCust": 0,
                    "createdTm": "2017-02-02 00:00:00",
                    "createLogin": null,
                    "xComments": "这是test"
                },
            ]
        }
    }
}