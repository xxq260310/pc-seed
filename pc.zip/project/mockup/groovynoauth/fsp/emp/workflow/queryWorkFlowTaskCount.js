/**
 * 代办流程（首页总数）
*/
exports.response = function (req, res) {
  return {
    "code": "0",
    "msg": "OK",
    "resultData": 129
  }
}
