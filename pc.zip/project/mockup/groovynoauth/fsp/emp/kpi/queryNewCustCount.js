/*
* 经营指标 新增客户指标区域数据
*/
exports.response = function (req, res) {
  return {
    "code": "0",
    "msg": "OK",
    "resultData": [0, 0, 0, 0],
  };
}
