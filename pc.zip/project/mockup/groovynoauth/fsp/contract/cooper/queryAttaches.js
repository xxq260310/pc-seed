exports.response = function (req, res) {
    return {
      "code": "0",
      "msg": "OK",
      "resultData": {
        "attaches": [
          {
            "creator": "002332",                                                                          //创建者
            "attachId": "{6795CB98-B0CD-4CEC-8677-3B0B9298B209}",
            "name": "新建文本文档 (3).txt",
            "size": "0",
            "createTime": "2017/09/12 13:37:45",
            "downloadURL": "http://ceflow:8086/unstructured/downloadDocument?sessionId=675fd3be-baca-4099-8b52-bf9dde9f2b59&documentId={6795CB98-B0CD-4CEC-8677-3B0B9298B209}",
            "realDownloadURL": "/attach/download?filename=%E6%96%B0%E5%BB%BA%E6%96%87%E6%9C%AC%E6%96%87%E6%A1%A3+%283%29.txt&attachId={6795CB98-B0CD-4CEC-8677-3B0B9298B209}"
          },
          {
            "creator": "002332",
            "attachId": "{2EF837DE-508C-4FCA-93B8-99CEA68DCB0D}",
            "name": "测试.docx",
            "size": "11",
            "createTime": "2017/09/12 11:53:36",
            "downloadURL": "http://ceflow:8086/unstructured/downloadDocument?sessionId=675fd3be-baca-4099-8b52-bf9dde9f2b59&documentId={2EF837DE-508C-4FCA-93B8-99CEA68DCB0D}",
            "realDownloadURL": "/attach/download?filename=%E6%B5%8B%E8%AF%95.docx&attachId={2EF837DE-508C-4FCA-93B8-99CEA68DCB0D}"
          },
          {
            "creator": "002332",
            "attachId": "{24C098F0-9DE3-4DC6-9E7D-FECE683E4B6F}",
            "name": "生产sql和修改后sql.txt",
            "size": "2",
            "createTime": "2017/09/12 11:55:32",
            "downloadURL": "http://ceflow:8086/unstructured/downloadDocument?sessionId=675fd3be-baca-4099-8b52-bf9dde9f2b59&documentId={24C098F0-9DE3-4DC6-9E7D-FECE683E4B6F}",
            "realDownloadURL": "/attach/download?filename=%E7%94%9F%E4%BA%A7sql%E5%92%8C%E4%BF%AE%E6%94%B9%E5%90%8Esql.txt&attachId={24C098F0-9DE3-4DC6-9E7D-FECE683E4B6F}"
          }
        ],
        "attachment": "01021505188412482"
      }
    }
}