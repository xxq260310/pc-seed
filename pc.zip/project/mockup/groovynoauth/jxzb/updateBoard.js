/**
 * 更新，发布看板
 */
exports.response = function (req, res) {
  return {
    code: '0',
    msg: 'OK',
    resultData: '发布成功',
  };
};