import SingleFilter from './SingleFilter';
import MultiFilter from './MultiFilter';

export default {
  SingleFilter,
  MultiFilter,
};
