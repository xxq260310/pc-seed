import Anchor from './Anchor';
// import AnchorLink from 'antd/lib/anchor/AnchorLink';
import AnchorLink from './AnchorLink';

Anchor.Link = AnchorLink;
export default Anchor;
