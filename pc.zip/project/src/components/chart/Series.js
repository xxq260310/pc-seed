/**
 * @file components/chart/Series.js
 * @author maoquan(maoquan@htsc.com)
 */

import ChartBase from './ChartBase';

export default class Series extends ChartBase {}
